import Residual_SqueezeNet
import tensorflow as tf
import numpy as np
import DeepMaxout

def main(inp_feat,feat,AU_det, lab, tr, ACC, TPR, TNR):

    #-------  residual squeezenet model -------

    l1 = Residual_SqueezeNet.squeeze_classify(inp_feat, lab, tr)

    #  ------  RS fusion DMN layer -------------

    opt = tf.keras.optimizers.RMSprop()  #### weight
    m = tf.keras.models.Sequential([tf.keras.layers.Dense(1)])
    m.compile(opt, loss='mse')

    m.fit(feat, lab)  # Training.
    w = np.mean(m.get_weights()[0])

    l = feat.shape[1]
    y = 0
    for i in range(l):
        y += (feat[:, i] * w)

    # -----  Applying fractional concept  --------
    h = 0.5       # constant
    l2 = h*y + 0.2 * h * l1

    # ---------   DMN model
    l2 = np.resize(l2,(len(AU_det),l2.shape[1]))
    Feat = np.concatenate((AU_det, l2), axis =1)

    l3, target = DeepMaxout.Dmax(Feat, lab, tr)

    # -------- for calculating metrics
    predict = l3
    uni = np.unique(target)

    tp, tn, fn, fp = 0, 0, 0, 0  # unique label
    for i1 in range(len(uni)):
        c = uni[i1]
        for i in range(len(target)):
            # print(i)
            if (target[i] == c and predict[i] == c):
                tp = tp + 1
            if (target[i] != c and predict[i] != c):
                tn = tn + 1
            if (target[i] == c and predict[i] != c):
                fn = fn + 1
            if (target[i] != c and predict[i] == c):
                fp = fp + 1

    tn = tn /len(uni)


    TPR.append(tp / (tp + fn))

    TNR.append(tn / (tn + fp))
    ACC.append((tp + tn) / (tp + tn + fp + fn))



