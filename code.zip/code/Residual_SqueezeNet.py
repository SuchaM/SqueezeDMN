import warnings
import numpy as np
from keras.utils import to_categorical
from keras.layers import Input, Dense, Layer, Concatenate, Add, Conv2D, MaxPool2D, GlobalAveragePooling2D, Dropout
from keras.models import Model
from sklearn.model_selection import train_test_split

warnings.simplefilter('ignore')

one = (1, 1)
three = (3, 3)
seven = (7, 7)


class FireModule(object):
    """
    Fire Module computed as per the SqueezeNet paper
    """

    def __init__(self, layer_number: int, activation: str, kernel_initializer: str) -> None:
        """
        Constructor

        Arguments:
          layer_number       : Index of the Fire Module
          activation         : Activation to be used
          kernel_initializer : Kernel Weight Initialization technique

        Returns:
          None
        """

        self.layer_number = layer_number
        self.activation = activation
        self.kernel_initializer = kernel_initializer

    def build_module(self, fire_input: Layer) -> Layer:
        """
        Build the SqueezeNet

        Arguments:
          fire_input       : Input to Fire Module

        Returns:
          model            : SqueezeNet
        """

        output_size = 128 * (1 + (self.layer_number // 2))

        squeeze_1x1_filters = 16 * (1 + (self.layer_number // 2))
        expand_1x1_filters = expand_3x3_filters = output_size // 2

        squeeze_1x1 = Conv2D(name=f'fire_{self.layer_number + 2}_squeeze_1x1',
                             filters=squeeze_1x1_filters, kernel_size=one, strides=1, padding='valid',
                             activation=self.activation,
                             kernel_initializer=self.kernel_initializer)(fire_input)
        expand_1x1 = Conv2D(name=f'fire_{self.layer_number + 2}_expand_1x1',
                            filters=expand_1x1_filters, kernel_size=one, strides=1, padding='valid',
                            activation=self.activation,
                            kernel_initializer=self.kernel_initializer)(squeeze_1x1)
        expand_3x3 = Conv2D(name=f'fire_{self.layer_number + 2}_expand_3x3',
                            filters=expand_3x3_filters, kernel_size=three, strides=1, padding='same',
                            activation=self.activation,
                            kernel_initializer=self.kernel_initializer)(squeeze_1x1)

        fire = Concatenate(name=f'fire_{self.layer_number + 2}')([expand_1x1, expand_3x3])

        return fire


class Residual_SqueezeNet(object):
    """
    Residual SqueezeNet Architecture
    """

    def __init__(self, activation: str = 'relu', kernel_initializer: str = 'glorot_uniform') -> None:
        """
        Constructor

        Arguments:
          activation         : Activation to be used
          kernel_initializer : Kernel Weight Initialization technique

        Returns:
          None
        """

        self.activation = activation
        self.kernel_initializer = kernel_initializer

    def build_model(self, input_shape: tuple = (224, 224, 3), n_classes: int = 4) -> Model:
        """
        Build Residual SqueezeNet

        Arguments:
          input_shape         : Input Shape of the images
          n_classes           : Number of output classes

        Returns:
          model               : Residual SqueezeNet Model
        """

        inp = Input(shape=input_shape, name='Input')

        # Conv1 Layer
        conv_1 = Conv2D(name="Conv_1",
                        filters=96, kernel_size=seven, strides=2, padding='same', activation=self.activation,
                        kernel_initializer=self.kernel_initializer)(inp)
        maxpool_1 = MaxPool2D(name="MaxPool_1",
                              pool_size=three, strides=2)(conv_1)

        # Fire 2-4
        fire_2 = FireModule(layer_number=0, activation=self.activation,
                            kernel_initializer=self.kernel_initializer).build_module(maxpool_1)
        fire_3 = FireModule(layer_number=1, activation=self.activation,
                            kernel_initializer=self.kernel_initializer).build_module(fire_2)
        fire_3_residual = Add()([fire_2, fire_3])  # Residual connection

        fire_4 = FireModule(layer_number=2, activation=self.activation,
                            kernel_initializer=self.kernel_initializer).build_module(fire_3_residual)

        # Max Pool after Fire4 Module
        maxpool_2 = MaxPool2D(name="MaxPool_2",
                              pool_size=three, strides=2)(fire_4)

        # Fire 5-8
        fire_5 = FireModule(layer_number=3, activation=self.activation,
                            kernel_initializer=self.kernel_initializer).build_module(maxpool_2)
        fire_5_residual = Add()([maxpool_2, fire_5])  # Residual connection
        fire_6 = FireModule(layer_number=4, activation=self.activation,
                            kernel_initializer=self.kernel_initializer).build_module(fire_5_residual)
        fire_7 = FireModule(layer_number=5, activation=self.activation,
                            kernel_initializer=self.kernel_initializer).build_module(fire_6)
        fire_7_residual = Add()([fire_6, fire_7])  # Residual connection
        fire_8 = FireModule(layer_number=6, activation=self.activation,
                            kernel_initializer=self.kernel_initializer).build_module(fire_7_residual)

        # Max Pool after Fire8 Module
        maxpool_3 = MaxPool2D(name="MaxPool_3",
                              pool_size=three, strides=2)(fire_8)

        fire_9 = FireModule(layer_number=7, activation=self.activation,
                            kernel_initializer=self.kernel_initializer).build_module(maxpool_3)
        fire_9_residual = Add()([maxpool_3, fire_9])  # Residual connection

        # Dropout
        dropout = Dropout(0.5, name="Dropout")(fire_9_residual)

        # Conv10 layer
        conv_10 = Conv2D(name="Conv_10",
                         filters=1000, kernel_size=one, strides=1, padding='valid', activation=self.activation,
                         kernel_initializer=self.kernel_initializer)(dropout)
        gap_11 = GlobalAveragePooling2D()(conv_10)

        out = Dense(n_classes, activation='softmax')(gap_11)

        model = Model(inputs=inp, outputs=out)

        return model


def squeeze_classify(data ,lab,tr):
    tr_data, tst_data, tr_lab, tst_lab = train_test_split(data, lab, train_size = tr, random_state=42)

    nc = len(np.unique(tr_lab))

    snet = Residual_SqueezeNet()
    model = snet.build_model(n_classes=nc)
    model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])

    tr_lab = to_categorical(tr_lab)
    tr_data = np.resize(tr_data, (tr_data.shape[0], 224, 224, 3))
    tr_lab = np.resize(tr_lab, (tr_lab.shape[0], nc))
    model.fit(tr_data, tr_lab, batch_size=64, epochs=1, verbose=0)
    tst_data = np.resize(tst_data, (tst_data.shape[0], 224, 224, 3))
    predict = model.predict(tst_data)

    return predict
