import numpy as np
import mahotas
import cv2
def surf(img):



    f = img.astype(np.uint8)

    from mahotas.features import surf
    spoints = surf.surf(f, 4, 6, 2)


    try:
        import milk

        descrs = spoints[:, 5:]
        k = 5
        values, _ = milk.kmeans(descrs, k)
        colors = np.array([(255 - 52 * i, 25 + 52 * i, 37 ** i % 101) for i in range(k)])
    except:
        values = np.zeros(100)
        colors = np.array([(255, 0, 0)])

    f1 = surf.show_surf(f, spoints[:100], values, colors)


    hist_surf, bin_edges = np.histogram(f1)
    return hist_surf