import cv2
import os




def face_detect(frame):
    cascPathface = os.path.dirname(
        cv2.__file__) + "/data/haarcascade_frontalface_alt2.xml"
    cascPatheyes = os.path.dirname(
        cv2.__file__) + "/data/haarcascade_eye_tree_eyeglasses.xml"

    faceCascade = cv2.CascadeClassifier(cascPathface)
    eyeCascade = cv2.CascadeClassifier(cascPatheyes)



    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    faces = faceCascade.detectMultiScale(gray,
                                         scaleFactor=1.1,
                                         minNeighbors=5,
                                         minSize=(60, 60),
                                         flags=cv2.CASCADE_SCALE_IMAGE)
    for (x,y,w,h) in faces:
        cv2.rectangle(frame, (x, y), (x + w, y + h),(0,255,0), 2)
        faceROI = frame[y:y+h,x:x+w]
        return faceROI


