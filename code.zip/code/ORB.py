import cv2
import numpy as np


def ORB(img):
    # Load images
    img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)


    # Initialize ORB detector
    orb = cv2.ORB_create()

    # Find keypoints and descriptors
    keypoints, descriptors = orb.detectAndCompute(img, None)

    # Draw keypoints on the image
    img_with_keypoints = cv2.drawKeypoints(img, keypoints, None, flags=cv2.DRAW_MATCHES_FLAGS_DRAW_RICH_KEYPOINTS)

    hist_orb, bin_edges = np.histogram(img_with_keypoints)
    return hist_orb