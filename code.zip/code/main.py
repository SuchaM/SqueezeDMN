import ORB
import SURF
import face_detection
import proposed
from scipy.stats import kurtosis, skew
import cv2
import numpy as np
import os
import torch
from AU_detection.network import ResNet

def loadnet(npoints = 10, path_to_model = None):
    # Load the trained model.
    net = ResNet(num_maps = npoints)
    checkpoint = torch.load(path_to_model, map_location = 'cpu')
    checkpoint = {k.replace('module.', ''): v for k, v in checkpoint.items()}
    net.load_state_dict(checkpoint, strict = False)
    return net.to('cpu')



def call_main(str, value):
    ''' pass the comparative analysysis in terms of training data  and frames
                                 example::::call_main('Frames',40) or call_main('Training data',50)'''
                           
    ACC, TPR, TNR = [], [], []
    if str == 'Frames':
        frames = int(value)
        tr = 0.9
    else:
        tr = int(value) / 100
        frames = 100
    # --------- read the video folder
    data_folder = r'dataset\train_sample_videos'
    lab = np.load('lab.npy')

    d1 = os.listdir(data_folder)
    feat = []
    inp_feat = []
    AU_det_feat = []
    for i1 in range(len(d1)):

        filename_1 = os.path.join(data_folder, d1[i1])

        cap = cv2.VideoCapture(filename_1)
        ## ------ extracting frames from the video
        frame_count = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))

        N_frame_want = frame_count
        frames_to_read = np.round(np.linspace(1, frame_count - 1, N_frame_want))
        for i2 in range(frames):
            print(i2)
            frame_seq = frames_to_read[i2]
            # frame_no = (frame_seq / (duration * fps))
            cap.set(1, frame_seq)
            ret, frame = cap.read()  # video to frame conversion
            img_clr = frame
            #------ for input frames feature
            hist, bin = np.histogram(img_clr)
            inp_feat.append(hist.tolist())



            # -----face detection-------

            detected  = face_detection.face_detect(img_clr)


            # ---------AU extraction---------

            net = loadnet(10, '.\model\model.pth')
            image_np = torch.from_numpy((detected / 255.0).swapaxes(2, 1).swapaxes(1, 0))
            img = image_np.type_as(torch.FloatTensor())
            heatmap = net(img[None, :])
            img_AU = heatmap.detach().cpu().numpy()
            img_AU = img_AU[0, :, :, :]

            AU_img = np.sum(img_AU, 0)
            AU_img = cv2.normalize(src=AU_img, dst=None, alpha=0, beta=255, norm_type=cv2.NORM_MINMAX,
                                    dtype=cv2.CV_8U)
            hist1, bin = np.histogram(AU_img)
            AU_det_feat.append(hist1.tolist())




            ############### feature extraction
            f1 = SURF.surf(AU_img)
            f2 = ORB.ORB(AU_img)

            a1 = AU_img.mean()       #      mean
            a2 = np.var(AU_img)      #      Variance
            a3 = np.std(AU_img)        #     standard deviation
            a4 = np.mean(kurtosis(AU_img))  #     kurtosis
            a5 = np.mean(skew(AU_img))  #     SKEWNESS



            f = f1.tolist() + f2.tolist()  + [a1, a2,a3,a4,a5] #    concatenation
            feat.append(f)

    feat = np.array(feat)

    inp_feat = np.array(inp_feat)
    AU_det = np.array(AU_det_feat)


    proposed.main(inp_feat,feat,AU_det, lab, tr, ACC, TPR, TNR)


    return ACC, TPR, TNR

